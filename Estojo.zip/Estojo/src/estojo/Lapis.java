package estojo;

public class Lapis {
	private String cor;
	private boolean apontado;
	private char escolar;
	
	public Lapis() {
		apontar();
		escolar = 'S';
	}
	
	public Lapis (String c, boolean a, char e) {
		this.cor = c;
		this.apontado = a;
		this.escolar = e;
	}
	
	public String getCor() {
		return cor;
	}
	
	public void setCor(String c) {
		this.cor = c;
	}
	
	public char getEscolar() {
		return escolar;
	}
	
	public void setEscolar(char e) {
		this.escolar = e;
	}
	
	public void apontar() {
		this.apontado = true;
	}
	public void desapontar() {
		this.apontado = false;
	}
	
	public void status() {
		System.out.println(" \nCor: " + getCor() + " \nApontado: " + apontado + " \nEscolar: " + getEscolar());
	}
	
}
