package estojo;

public class Canetao {
	private float ponta;
	private boolean tampada;
	private String cor;
	
	public Canetao() {
		
	}
	
	public Canetao(float p, boolean t, String c) {
		this.ponta = p;
		this.tampada = t;
		this.cor = c;
		
	}
	
	
	public float getPonta() {
		return ponta;
	}
	
	public void setPonta(float p) {
		this.ponta = p;
	}
	
	public String getCor() {
		return cor;
	}
	
	public void setCor(String c) {
		this.cor = c;
	}
	public void tampar() {
		tampada = true;
	}
	
	public void destampar() {
		tampada = false;
	}

	public void status() {
		System.out.println(" \nPonta: " + getPonta() + " \nTampada: " + tampada + " \nCor: " + getCor());
	}
}
