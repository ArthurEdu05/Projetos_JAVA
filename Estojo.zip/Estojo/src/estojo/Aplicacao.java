package estojo;

public class Aplicacao {
	
	public static void main (String[]args) {
	
		Caneta c1 = new Caneta();
		c1.setModelo("BIC");
		c1.setPonta(0.04f);
		c1.status();
		
		
		Caneta c2 = new Caneta("SLA", 0.09f, false,"Vermelha" );
		c2.status();
		
		Caneta c3 = new Caneta("UAU", 0.07f,true,"Preta");
		c3.status();
		
		
		Canetao cao1 = new Canetao();
		cao1.setPonta(0.12f);
		cao1.destampar();
		cao1.setCor("VERMELHASSA");
		cao1.status();
		
		Canetao cao2 = new Canetao(0.14f, true, "PRETASSA");
		cao2.status();
		
		Lapis l1 = new Lapis();
		l1.setCor("Pretinho");
		l1.desapontar();
		l1.setEscolar('N');
		l1.status();
		
		Lapis l2 = new Lapis("Vermelhinho", true, 'S');
		l2.status();
}
	}
