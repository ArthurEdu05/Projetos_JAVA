package estojo;

public class Caneta {
	private String modelo;
	private float ponta;
	private boolean tampada;
	private String cor;
	
	public Caneta() {
		tampar();
		cor = "Azul";
	}
	
	public Caneta(String m, float p, boolean t, String c) {
		this.modelo =m;
		this.ponta = p;
		this.tampada=t;
		this.cor = c;
	}
	
	public String getModelo(){
		return modelo;
	}
	
	public void setModelo(String m) {
		this.modelo = m;
	}
	
	public float getPonta(){
		return ponta;
	}
	
	public void setPonta(float p) {
		this.ponta = p;
	}
	
	public void tampar() {
		this.tampada = true;
	}
	
	public void destampar() {
		this.tampada = false;
	}
	
	
	
	
	public void status() {
		System.out.println(" \nModelo: " + getModelo() + " \nPonta: " + getPonta()
		+ " \nTampada: " + tampada + " \nCor: " + cor) ;
	
	}
}
