package atividade;


public abstract class Pet {
    private String raca;
    private Data nascimento;
    private String cor;
    private String nome;
    private Pessoa dono;

    public Pet(String raca, Data nascimento, String cor, String nome) {
        this.raca = raca;
        this.nascimento = nascimento;
        this.cor = cor;
        this.nome = nome;
    }

    public String getRaca() {
        return raca;
    }

    public Data getNascimento() {
        return nascimento;
    }

    public String getCor() {
        return cor;
    }

    public String getNome() {
        return nome;
    }

    public Pessoa meuDono() {
        return dono;
    }

    public int calcularIdade() {
        int currentYear = java.time.LocalDate.now().getYear();
        return currentYear - nascimento.getAno();
    }


    public void atribuirDono(Pessoa dono) {
        this.dono = dono;
    }

    public void perderDono() {
        this.dono = null;
    }

    public abstract void emitirSom();

    @Override
    public String toString() {
        return "Nome: " + nome + ", Raça: " + raca + ", Idade: " + calcularIdade();
    }
}

