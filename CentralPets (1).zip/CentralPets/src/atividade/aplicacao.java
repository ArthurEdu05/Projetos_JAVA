package atividade;

import java.util.Scanner;

public class aplicacao {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        CentralPets centralPets = new CentralPets();

        int op;
        do {
            System.out.println("\n--- Central de Pets ---");
            System.out.println("1. Criar Pessoa");
            System.out.println("2. Criar Cachorro");
            System.out.println("3. Criar Gato");
            System.out.println("4. Adquirir Cachorro");
            System.out.println("5. Adquirir Gato");
            System.out.println("6. Listar Pessoas");
            System.out.println("7. Listar Pets de uma Pessoa");
            System.out.println("8. Devolver Cachorro");
            System.out.println("9. Devolver Gato");
            System.out.println("10. Listar Cachorros com Dono");
            System.out.println("11. Listar Gatos com Dono");
            System.out.println("12. Listar Cachorros sem Dono");
            System.out.println("13. Listar Gatos sem Dono");
            System.out.println("14. Listar Cachorros de um Determinado Dono");
            System.out.println("15. Listar Gatos de um Determinado Dono");
            System.out.println("16. Listar Pessoas sem Pets");
            System.out.println("17. Listar Pessoa com mais Pets");
            System.out.println("18. Obter Dono de um Cachorro");
            System.out.println("19. Obter Dono de um Gato");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            op = Integer.parseInt(entrada.nextLine());

            switch (op) {
                case 1 -> {
                    System.out.print("Nome: ");
                    String nome = entrada.nextLine();
                    System.out.print("CPF: ");
                    String cpf = entrada.nextLine();
                    System.out.print("Telefone: ");
                    String telefone = entrada.nextLine();
                    centralPets.criarPessoa(nome, cpf, telefone);
                }
                case 2 -> {
                    System.out.print("Raça do Cachorro: ");
                    String raca = entrada.nextLine();
                    System.out.print("Nome: ");
                    String nome = entrada.nextLine();
                    System.out.print("Cor: ");
                    String cor = entrada.nextLine();
                    System.out.print("Ano de nascimento: ");
                    int ano = Integer.parseInt(entrada.nextLine());
                    System.out.print("Mês de nascimento: ");
                    int mes = Integer.parseInt(entrada.nextLine());
                    System.out.print("Dia de nascimento: ");
                    int dia = Integer.parseInt(entrada.nextLine());
                    centralPets.criarCachorro(raca, new Data(dia, mes, ano), cor, nome);
                }
                case 3 -> {
                    System.out.print("Raça do Gato: ");
                    String raca = entrada.nextLine();
                    System.out.print("Nome: ");
                    String nome = entrada.nextLine();
                    System.out.print("Cor: ");
                    String cor = entrada.nextLine();
                    System.out.print("Ano de nascimento: ");
                    int ano = Integer.parseInt(entrada.nextLine());
                    System.out.print("Mês de nascimento: ");
                    int mes = Integer.parseInt(entrada.nextLine());
                    System.out.print("Dia de nascimento: ");
                    int dia = Integer.parseInt(entrada.nextLine());
                    centralPets.criarGato(raca, new Data(dia, mes, ano), cor, nome);
                }
                case 4 -> {
                    Pessoa pessoa = buscarPessoa(entrada, centralPets);
                    if (pessoa != null) {
                        System.out.print("Informe o nome do cachorro a ser adquirido: ");
                        String nomeCachorro = entrada.nextLine();
                        Cachorro cachorro = buscarCachorroPorNome(nomeCachorro, centralPets);
                        if (cachorro != null) {
                            centralPets.adquirirCachorro(pessoa, cachorro);
                        } else {
                            System.out.println("Cachorro não encontrado.");
                        }
                    }
                }
                case 5 -> {
                    Pessoa pessoa = buscarPessoa(entrada, centralPets);
                    if (pessoa != null) {
                        System.out.print("Informe o nome do gato a ser adquirido: ");
                        String nomeGato = entrada.nextLine();
                        Gato gato = buscarGatoPorNome(nomeGato, centralPets);
                        if (gato != null) {
                            centralPets.adquirirGato(pessoa, gato);
                        } else {
                            System.out.println("Gato não encontrado.");
                        }
                    }
                }
                case 6 -> centralPets.listarPessoas();
                case 7 -> {
                    Pessoa pessoa = buscarPessoa(entrada, centralPets);
                    if (pessoa != null) {
                        centralPets.listarPetsDePessoa(pessoa);
                    }
                }
                case 8 -> {
                    Pessoa pessoa = buscarPessoa(entrada, centralPets);
                    if (pessoa != null) {
                        centralPets.devolverCachorro(pessoa);
                    }
                }
                case 9 -> {
                    Pessoa pessoa = buscarPessoa(entrada, centralPets);
                    if (pessoa != null) {
                        centralPets.devolverGato(pessoa);
                    }
                }
                case 10 -> centralPets.obterCachorrosComDono();
                case 11 -> centralPets.obterGatosComDono();
                case 12 -> centralPets.obterCachorrosSemDono();
                case 13 -> centralPets.obterGatosSemDono();
                case 14 -> {
                    Pessoa pessoa = buscarPessoa(entrada, centralPets);
                    if (pessoa != null) {
                        centralPets.listarCachorrosDeterminadoDono(pessoa);
                    }
                }
                case 15 -> {
                    Pessoa pessoa = buscarPessoa(entrada, centralPets);
                    if (pessoa != null) {
                        centralPets.listarGatosDeterminadoDono(pessoa);
                    }
                }
                case 16 -> centralPets.listarPessoasSemPets();
                case 17 -> centralPets.listarPessoasComMaisPets();
                case 18 -> {
                    System.out.print("Informe o nome do cachorro: ");
                    String nomeCachorro = entrada.nextLine();
                    Cachorro cachorro = buscarCachorroPorNome(nomeCachorro, centralPets);
                    if (cachorro != null) {
                        centralPets.obterDonoDeterminadoCachorro(cachorro);
                    } else {
                        System.out.println("Cachorro não encontrado.");
                    }
                }
                case 19 -> {
                    System.out.print("Informe o nome do gato: ");
                    String nomeGato = entrada.nextLine();
                    Gato gato = buscarGatoPorNome(nomeGato, centralPets);
                    if (gato != null) {
                        centralPets.obterDonoDeterminadoGato(gato);
                    } else {
                        System.out.println("Gato não encontrado.");
                    }
                }
                case 0 -> System.out.println("Encerrando o sistema...");
                default -> System.out.println("Opção inválida!");
            }
        } while (op != 0);

        entrada.close();
    }

    private static Pessoa buscarPessoa(Scanner scanner, CentralPets centralPets) {
        System.out.print("Informe o CPF da pessoa: ");
        String cpf = scanner.nextLine();

        Pessoa pessoa = centralPets.buscarPessoa(cpf);
        if (pessoa == null) {
            System.out.println("Pessoa com CPF " + cpf + " não encontrada.");
        }
        return pessoa;
    }

    private static Cachorro buscarCachorroPorNome(String nome, CentralPets centralPets) {
        for (Cachorro cachorro : centralPets.getCachorros()) {
            if (cachorro.getNome().equalsIgnoreCase(nome)) {
                return cachorro;
            }
        }
        return null;
    }

    private static Gato buscarGatoPorNome(String nome, CentralPets centralPets) {
        for (Gato gato : centralPets.getGatos()) {
            if (gato.getNome().equalsIgnoreCase(nome)) {
                return gato;
            }
        }
        return null;
    }
}
