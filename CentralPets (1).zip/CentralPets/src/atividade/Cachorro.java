package atividade;

class Cachorro extends Pet {
    public Cachorro(String raca, Data nascimento, String cor, String nome) {
        super(raca, nascimento, cor, nome);
    }

    @Override
    public void emitirSom() {
    	 System.out.println("AU AU AU");
    }

    @Override
    public String toString() {
        return super.toString() + " (Cachorro)";
    }
}

