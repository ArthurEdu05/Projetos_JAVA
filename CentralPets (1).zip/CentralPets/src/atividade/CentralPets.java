package atividade;

import java.util.ArrayList;
import java.util.List;

public class CentralPets {
    private List<Pessoa> pessoas;
    private List<Cachorro> cachorros;
    private List<Gato> gatos;

    public CentralPets() {
        pessoas = new ArrayList<>();
        cachorros = new ArrayList<>();
        gatos = new ArrayList<>();
    }

    public void criarPessoa(String nome, String cpf, String telefone) {
        if (buscarPessoa(cpf) != null) {
            System.out.println("CPF já cadastrado!");
            return;
        }
        pessoas.add(new Pessoa(nome, cpf, telefone));
        System.out.println("Pessoa criada com sucesso!");
    }


    public Pessoa buscarPessoa(String cpf) {
        for (Pessoa pessoa : pessoas) {
            if (pessoa.getCpf().equals(cpf)) {
                return pessoa;
            }
        }
        return null;
    }


    public void criarCachorro(String raca, Data nascimento, String cor, String nome) {
        Cachorro cachorro = new Cachorro(raca, nascimento, cor, nome);
        cachorros.add(cachorro);
        System.out.println("Cachorro criado: " + cachorro);
        cachorro.emitirSom();
    }


    public void criarGato(String raca, Data nascimento, String cor, String nome) {
        Gato gato = new Gato(raca, nascimento, cor, nome);
        gatos.add(gato);
        System.out.println("Gato criado: " + gato);
        gato.emitirSom();
    }


    public void adquirirCachorro(Pessoa pessoa, Cachorro cachorro) {
        if (cachorro.meuDono() == null) {
            pessoa.adquirirCachorro(cachorro);
            System.out.println("Cachorro adquirido com sucesso!");
        } else {
            System.out.println("Esse cachorro já possui dono!");
        }
    }


    public void adquirirGato(Pessoa pessoa, Gato gato) {
        if (gato.meuDono() == null) {
            pessoa.adquirirGato(gato);
            System.out.println("Gato adquirido com sucesso!");
        } else {
            System.out.println("Esse gato já possui dono!");
        }
    }


    public void listarPessoas() {
        if (pessoas.isEmpty()) {
            System.out.println("Nenhuma pessoa cadastrada.");
        } else {
            for (Pessoa pessoa : pessoas) {
                System.out.println(pessoa);
            }
        }
    }

    public void listarPetsDePessoa(Pessoa pessoa) {
        List<Pet> pets = pessoa.getPets();
        if (pets.isEmpty()) {
            System.out.println("Essa pessoa não possui pets.");
        } else {
            System.out.println("Pets de " + pessoa.getNome() + ":");
            for (Pet pet : pets) {
                System.out.println(pet);
            }
        }
    }

    public void devolverCachorro(Pessoa pessoa) {
        List<Pet> pets = pessoa.getPets();
        pets.removeIf(pet -> {
            if (pet instanceof Cachorro) {
                pet.perderDono();
                System.out.println("Cachorro devolvido: " + pet.getNome());
                return true;
            }
            return false;
        });
    }

    
    public void devolverGato(Pessoa pessoa) {
        List<Pet> pets = pessoa.getPets();
        pets.removeIf(pet -> {
            if (pet instanceof Gato) {
                pet.perderDono();
                System.out.println("Gato devolvido: " + pet.getNome());
                return true;
            }
            return false;
        });
    }

   
    public void obterCachorrosComDono() {
        boolean encontrado = false;
        for (Cachorro cachorro : cachorros) {
            if (cachorro.meuDono() != null) {
                System.out.println(cachorro + " - Dono: " + cachorro.meuDono().getNome());
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Nenhum cachorro com dono encontrado.");
        }
    }

   
    public void obterGatosComDono() {
        boolean encontrado = false;
        for (Gato gato : gatos) {
            if (gato.meuDono() != null) {
                System.out.println(gato + " - Dono: " + gato.meuDono().getNome());
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Nenhum gato com dono encontrado.");
        }
    }

    
    public void obterCachorrosSemDono() {
        boolean encontrado = false;
        for (Cachorro cachorro : cachorros) {
            if (cachorro.meuDono() == null) {
                System.out.println(cachorro);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Nenhum cachorro sem dono encontrado.");
        }
    }

  
    public void obterGatosSemDono() {
        boolean encontrado = false;
        for (Gato gato : gatos) {
            if (gato.meuDono() == null) {
                System.out.println(gato);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Nenhum gato sem dono encontrado.");
        }
    }


    public void listarCachorrosDeterminadoDono(Pessoa pessoa) {
        boolean encontrado = false;
        for (Pet pet : pessoa.getPets()) {
            if (pet instanceof Cachorro) {
                System.out.println(pet);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("A pessoa não possui cachorros.");
        }
    }

 
    public void listarGatosDeterminadoDono(Pessoa pessoa) {
        boolean encontrado = false;
        for (Pet pet : pessoa.getPets()) {
            if (pet instanceof Gato) {
                System.out.println(pet);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("A pessoa não possui gatos.");
        }
    }

  
    public void listarPessoasSemPets() {
        boolean encontrado = false;
        for (Pessoa pessoa : pessoas) {
            if (pessoa.getPets().isEmpty()) {
                System.out.println(pessoa);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Nenhuma pessoa sem pets encontrada.");
        }
    }


    public void listarPessoasComMaisPets() {
        if (pessoas.isEmpty()) {
            System.out.println("Nenhuma pessoa cadastrada.");
            return;
        }

        Pessoa pessoaComMaisPets = pessoas.get(0);
        for (Pessoa pessoa : pessoas) {
            if (pessoa.getPets().size() > pessoaComMaisPets.getPets().size()) {
                pessoaComMaisPets = pessoa;
            }
        }
        System.out.println("Pessoa com mais pets: " + pessoaComMaisPets.getNome() + " - Total de Pets: " + pessoaComMaisPets.getPets().size());
    }

    
    public void obterDonoDeterminadoCachorro(Cachorro cachorro) {
        if (cachorro.meuDono() != null) {
            System.out.println("Dono do cachorro " + cachorro.getNome() + ": " + cachorro.meuDono().getNome());
        } else {
            System.out.println("O cachorro " + cachorro.getNome() + " não tem dono.");
        }
    }

    public void obterDonoDeterminadoGato(Gato gato) {
        if (gato.meuDono() != null) {
            System.out.println("Dono do gato " + gato.getNome() + ": " + gato.meuDono().getNome());
        } else {
            System.out.println("O gato " + gato.getNome() + " não tem dono.");
        }
    }

    public List<Cachorro> getCachorros() {
        return cachorros;
    }

    public List<Gato> getGatos() {
        return gatos;
    }
}
