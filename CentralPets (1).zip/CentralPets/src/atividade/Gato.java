package atividade;

class Gato extends Pet {
    public Gato(String raca, Data nascimento, String cor, String nome) {
        super(raca, nascimento, cor, nome);
    }

    @Override
    public void emitirSom() {
    	 System.out.println("Miau!");
    }

    @Override
    public String toString() {
        return super.toString() + " (Gato)";
    }
}