package exposicao;

public class Animal {
	private String nome;
	private String cor;
	private String ambiente;
	private float comprimento;
	private float velocidade;
	private int patas;
	

	public Animal() {
		
	}
	
	public Animal(String n, String cor, String a, float comp, float v, int p) {
		this.nome = n;
		this.cor = cor;
		this.ambiente = a;
		this.comprimento = comp;
		this.velocidade = v;
		this.patas = p;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String n) {
		this.nome = n;
	}
	
	
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	
	
	public String getAmbiente() {
		return ambiente;
	}
	public void setAmbiente(String a) {
		this.ambiente = a;
	}
	
	public float getComprimento() {
		return comprimento;
	}
	public void setComprimento(float comp) {
		this.comprimento = comp;
	}
	
	public float getVelocidade() {
		return velocidade;
	}
	public void setVelocidade(float v) {
		this.velocidade = v;
	}
	
	public int getPatas() {
		return patas;
	}
	public void setPatas(int p) {
		this.patas = p;
	}
	
	public void dados() {
		System.out.println("\nNome: " + getNome() + "\nCor: " + getCor() + 
		"\nAmbiente: " + getAmbiente() + "\nComprimento: " + getComprimento() + " cm" + 
		"\nVelocidade: " + getVelocidade() +" km/h"+ "\nPatas: " + getPatas());
		
		
	}
}
