package exposicao;

public class Reptil extends Animal {
	private boolean nadar;
	
	public Reptil() {
		
	}
	public Reptil(String nome, String cor, String a, float comp, float v, int p,boolean n) {
		super(nome, cor, a, comp, v, p);
		this.nadar = n;
	}
	
	public boolean getNadar(){
		return nadar;
	}
	public void setNadar(boolean n) {
		this.nadar = n;
	}
	
	@Override
	public void dados() {
		super.dados();
		System.out.print("Nada? " + getNadar());
	}
}
