package exposicao;

public class Aplicacao {

	public static void main(String[] args) {
		Mamifero camelo = new Mamifero("Barnabé", "Amarelo", "Deserto",150.0f, 15.0f, 4,"pasto");
		camelo.dados();
		Peixe nemo = new Peixe("Nemo", "Laranja", "Aquático", 0.80f, 5.0f, 0, "Laranja com listras Pretas e Brancas");
		nemo.dados();
		Mamifero urso = new Mamifero("Catatau", "Marrom", "Floresta", 200.00f, 10.0f, 4, "Mel");
		urso.dados();
		Ave gaviao = new Ave("Gavião","","Céu", 0.4f, 80f,2, true);
		gaviao.dados();
		Reptil crocodilo= new Reptil("Crocodilo TUTU", "Verde", "Lago", 300.00f, 12.00f, 4, true);
		crocodilo.dados();
	}

}
