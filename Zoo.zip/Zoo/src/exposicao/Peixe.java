package exposicao;

public class Peixe extends Animal{
	private String desc;

	public Peixe() {
		
	}
	
	public Peixe(String n, String cor, String a, float comp, float v, int p, String desc ) {
		super(n, cor, a, comp, v, p);
		this.desc = desc;
		
	}
	public String getDesc() {
		return desc;
	}
	
	public void setDesc(String d) {
		this.desc = d;
	}

	@Override
	public void dados() {
		super.dados();
		System.out.print("Descrição: " + getDesc() + "\n");
	}
}
