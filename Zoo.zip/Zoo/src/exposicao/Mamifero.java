package exposicao;

public class Mamifero extends Animal{
	private String alimento;

	public Mamifero() {
		
	}
	
	public Mamifero(String nome, String cor, String amb, float comp, float v, int p, String ali) {
		super(nome, cor, amb, comp, v, p);
		this.alimento = ali;
	}
	public String getAlimento() {
		return alimento;
	}
	public void setAlimento(String a) {
		this.alimento = a;
	}
	
	public void dados() {
		super.dados();
		System.out.print("Alimento: " + getAlimento() +"\n");
	}
}
