package exposicao;

public class Ave extends Animal{
	private boolean voar;
	
	public Ave() {
		
	}
	public Ave(String n, String cor, String a, float comp, float v, int p, boolean voar) {
		super(n,cor, a, comp, v,p);
		this.voar = voar;
		
	}
	public boolean getVoar(){
		return voar;
	}
	public void setVoar(boolean v) {
		this.voar = v;
	}
	
	@Override
	public void dados() {
		System.out.println("\nNome: " + getNome() + 
				"\nAmbiente: " + getAmbiente() + "\nComprimento: " + getComprimento() + " cm" + 
				"\nVelocidade: " + getVelocidade() +" km/h"+ "\nPatas: " + getPatas() + "\nVoa? " + getVoar());
		
	}
}
