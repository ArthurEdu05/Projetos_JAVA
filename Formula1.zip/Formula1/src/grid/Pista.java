package grid;

public class Pista {
	private String local;
	private String clima;
	private float temp;
	
	public Pista() {
		
	}
	
	public Pista(String l, String c, float t) {
		this.local = l;
		this.clima = c;
		this.temp = t;
		
	}
	
	
	public String getLocal() {
		return local;
	}
	
	public void setLocal(String l) {
		this.local = l;
	}
	
	public String getClima() {
		return clima;
	}
	public void setClima(String c) {
		this.clima =c;
	}
	public float getTemp() {
		return temp;
	}
	public void setTemp(float t) {
		this.temp = t;
	}
	public void status() {
		System.out.print("Local: " + getLocal() + "\nClima: " + getClima() + "\nTemperatura: " + getTemp() + "°C");
		System.out.println();
		System.out.println();
	}

}
