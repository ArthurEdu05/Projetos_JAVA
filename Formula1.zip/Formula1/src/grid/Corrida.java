package grid;

public class Corrida {
	public static void main (String [] args) {
		
		Pista corrida = new Pista("Mônaco", "Chuva", 12.5f);
		corrida.status();
		
		Piloto p1 = new Piloto();
		p1.setNome("Hamilton");
		p1.setEquipe("Ferrari");
		p1.classificar();
		p1.setPosicao(1);
		p1.status();
		
		
		Piloto p2 = new Piloto("Verstappen", "Red Bull", true, 2);
		p2.status();	
		
		Piloto p3 = new Piloto("Bortoleto", "Sauber", true,3);
		p3.status();
		
		Piloto p4 = new Piloto();
		p4.setNome("Norris");
		p4.setEquipe("McLaren");
		p4.desclassificar();
		p4.setPosicao(4);
		p4.status();
		}
}
