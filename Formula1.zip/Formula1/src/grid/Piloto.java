package grid;

public class Piloto {
	private String nome;
	private String equipe;
	private boolean classificado;
	private int posicao;
	
	public Piloto() {
		
	}
	
	public Piloto(String n, String e, boolean c, int p) {
		this.nome = n;
		this.equipe = e;
		this.classificado = c;
		this.posicao = p;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String n) {
		this.nome = n;
	}
	
	public String getEquipe() {
		return equipe;
	}
	
	public void setEquipe(String e) {
		this.equipe = e;
	}
	
	public void classificar() {
		classificado = true;
	}
	
	public void desclassificar() {
		classificado = false;
	}
	
	public int getPosicao() {
		return posicao;
	}
	public void setPosicao(int p) {
		this.posicao = p;
	}
	
	public void status() {
		System.out.println(" \nNome do Piloto: " + getNome() + " \nEquipe: "+ getEquipe() + " \nClassificado: "+ classificado + " \nPosição: " + getPosicao()+"º" );
		
	}
	
}
