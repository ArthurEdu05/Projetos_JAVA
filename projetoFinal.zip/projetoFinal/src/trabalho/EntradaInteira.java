//Arthur Eduardo de Almeida Santos
//Guilherme Sampaio Silva
//Felipe Ferreira Melantonio

package trabalho;
//EntradaInteira é definida como uma subclasse da classe Entrada
class EntradaInteira extends Entrada {
    public EntradaInteira(int numeroDoAssento) {
        super(numeroDoAssento); //O super invoca o construtor da classe pai (que inicializa atributos da classe Entrada, como o número do assento).
    }

//calcular o valor do ingresso (retorna o preco inteiro sem descontos)
    public double calculaValor(double precoInteira) {
        return precoInteira;
    }
}
