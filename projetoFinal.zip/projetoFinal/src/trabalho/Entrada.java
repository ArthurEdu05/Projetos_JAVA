//Arthur Eduardo de Almeida Santos
//Guilherme Sampaio Silva
//Felipe Ferreira Melantonio

package trabalho;
//criando classe entrada que fala sobre a organização dos assentos
abstract class Entrada {
    protected int numeroDoAssento;

    public Entrada(int numeroDoAssento) {
        this.numeroDoAssento = numeroDoAssento;
    }

    public int getNumeroDoAssento() {
        return numeroDoAssento;
    }

    public abstract double calculaValor(double precoInteira);
}
