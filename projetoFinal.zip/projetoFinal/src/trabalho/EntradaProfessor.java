//Arthur Eduardo de Almeida Santos
//Guilherme Sampaio Silva
//Felipe Ferreira Melantonio

package trabalho;
//EntradaProfessor é definida como uma subclasse da classe Entrada
class EntradaProfessor extends Entrada {
    public EntradaProfessor(int numeroDoAssento) {
        super(numeroDoAssento); //O super invoca o construtor da classe pai (que inicializa atributos da classe Entrada, como o número do assento).
    }

    
  //Pega o precoInteira e retorna 40% do valor dela (Entrada Professor)
    public double calculaValor(double precoInteira) {
        return precoInteira * 0.4;
    }
}
