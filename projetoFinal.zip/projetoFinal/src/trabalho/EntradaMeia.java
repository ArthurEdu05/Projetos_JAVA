//Arthur Eduardo de Almeida Santos
//Guilherme Sampaio Silva
//Felipe Ferreira Melantonio

package trabalho;
//EntradaMeia é definida como uma subclasse da classe Entrada
class EntradaMeia extends Entrada {
    public EntradaMeia(int numeroDoAssento) {
        super(numeroDoAssento); //O super invoca o construtor da classe pai (que inicializa atributos da classe Entrada, como o número do assento).
    }

//Pega o precoInteira e retorna a metade do valor dela (Meia entrada)
    public double calculaValor(double precoInteira) {
        return precoInteira * 0.5;
    }
}
