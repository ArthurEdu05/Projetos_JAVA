package trabalho;
//Arthur Eduardo de Almeida Santos
//Guilherme Sampaio Silva
//Felipe Ferreira Melantonio

import java.util.ArrayList;
import java.util.List;

class Espetaculo {
 // Atributos privados da classe Espetaculo, que representam informações sobre o evento.
    private String nome;
    private String data;
    private String horario;
    private double preco;
    private List<Integer> assentosDisponiveis;  // Lista de assentos disponíveis para o espetáculo.

 // Construtor que inicializa o espetáculo com nome, data, horário e preço.
    public Espetaculo(String nome, String data, String horario, double preco) {
        this.nome = nome;
        this.data = data;
        this.horario = horario;
        this.preco = preco;
 // Inicializando a lista de assentos disponíveis (50 assentos, numerados de 1 a 50).
        this.assentosDisponiveis = new ArrayList<>(); 
        for (int i = 1; i <= 50; i++) {
            assentosDisponiveis.add(i); // Adiciona os assentos de 1 a 50 à lista de assentos disponíveis.
        }
    }
    
    
    // Métodos getters para acessar os atributos privados da classe.
    public String getNome() { return nome; }
    public String getData() { return data; }
    public String getHorario() { return horario; }
    public double getPreco() { return preco; }
    public List<Integer> getAssentosDisponiveis() { return assentosDisponiveis; }
    
    
    // Método que cria uma nova entrada (ingresso) para um determinado tipo e assento
    public Entrada novaEntrada(int tipo, int assento) {
        switch (tipo) {
            case 1:
                return new EntradaInteira(assento);
            case 2:
                return new EntradaMeia(assento);
            case 3:
                return new EntradaProfessor(assento);
            default:
            	// Se o tipo de entrada não for válido, lança uma exceção.
                throw new IllegalArgumentException("Tipo de entrada inválido.");
        }
    }
 // Método para reservar um assento (retira o assento da lista de assentos disponíveis).
    public void reservarAssento(int assento) {
        assentosDisponiveis.remove(Integer.valueOf(assento)); // Remove o assento da lista de assentos disponíveis.
    }

    // Método para exibir assentos em uma visualização formatada de 10 assentos por linha
    public void exibirAssentos() {
        System.out.println("\n||| Assentos Disponíveis |||");
     // Loop para iterar sobre os 50 assentos possíveis
        for (int i = 0; i < 50; i++) {
            if (assentosDisponiveis.contains(i + 1)) {
     // Se o assento estiver disponível, imprime o número do assento.
                System.out.printf("%02d ", i + 1);
            } else {
     // Se o assento estiver ocupado, imprime "XX".
                System.out.print("XX ");
            }
     // Depois de cada 10 assentos, quebra uma linha.
            if ((i + 1) % 10 == 0) {
                System.out.println();
            }
        }
    }
 // Método para liberar um assento (retorna o assento à lista de disponíveis)
    public void liberarAssento(int numeroAssento) {
 // Verifica se o assento não está mais na lista (está reservado)
        if (!assentosDisponiveis.contains(numeroAssento)) {
 // Se o assento não estiver disponível, adiciona-o de volta à lista
            assentosDisponiveis.add(numeroAssento);
        }
    }
}
