//Arthur Eduardo de Almeida Santos
//Guilherme Sampaio Silva
//Felipe Ferreira Melantonio

package trabalho;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MackTheater {
    private static List<Espetaculo> espetaculos = new ArrayList<>(); // Lista de espetáculos cadastrados
    private static List<Cliente> clientes = new ArrayList<>();	// Lista de clientes cadastrados
    private static Scanner scanner = new Scanner(System.in);	// Objeto Scanner para capturar entradas do usuário

    public static void main(String[] args) {
// Loop contínuo até o usuário escolher a opção de sair
        while (true) {
        	 // Exibe o menu de opções para o usuário
            System.out.println("*** MACK THEATER ***");
            System.out.println("1) Cadastrar Espetáculo");
            System.out.println("2) Cadastrar Cliente");
            System.out.println("3) Compra de Entradas");
            System.out.println("4) Sair");
            System.out.print("Selecione uma opção: ");
            
// Lê a opção escolhida pelo usuário
            int opcao = scanner.nextInt();
            scanner.nextLine();  

            switch (opcao) {
                case 1:
                    cadastrarEspectaculo();
                    break;
                case 2:
                    cadastrarCliente();
                    break;
                case 3:
                    compraEntradas();
                    break;
                case 4:
                    System.out.println("Encerrando o sistema...");
                    System.out.println("ENCERRADO!");
                    return; // Encerra o programa
                default:
                	// Caso o usuário digite uma opção inválida
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }
 // Método para cadastrar um novo espetáculo
    private static void cadastrarEspectaculo() {
    	// Solicita os dados do espetáculo
        System.out.println("\n*** CADASTRO DE ESPETÁCULO ***");
        System.out.print("Nome do Espetáculo: ");
        String nome = scanner.nextLine();
        System.out.print("Data (dd/MM/yyyy): ");
        String data = scanner.nextLine();
        System.out.print("Horário: ");
        String horario = scanner.nextLine();
        System.out.print("Preço da Entrada Inteira: ");
        double preco = scanner.nextDouble();
        scanner.nextLine();  

// Cria um novo objeto Espetaculo e adiciona na lista de espetáculos
        Espetaculo espetaculo = new Espetaculo(nome, data, horario, preco);
        espetaculos.add(espetaculo);
// Exibe a confirmação de cadastro
        System.out.printf(">>> Espetáculo cadastrado com sucesso! <<<\n" +
                          "Nome do Espetáculo: %s \nData: %s \nHora: %s \nPreço da Entrada Inteira: %.2f\n", 
                          nome, data, horario, preco);
        System.out.println(">>> Retornando ao menu principal <<<\n");
    }

    
 // Método para cadastrar um novo cliente
    private static void cadastrarCliente() {
        System.out.println("\n*** CADASTRO DE CLIENTE ***");
        // Solicita os dados do cliente
        System.out.print("Nome do Cliente: ");
        String nome = scanner.nextLine();
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();

        // Cria um novo cliente e adiciona à lista de clientes
        Cliente cliente = new Cliente(nome, cpf);
        clientes.add(cliente);
        
        // Exibe a confirmação de cadastro
        System.out.println(">>> Cliente cadastrado com sucesso! <<<");
        System.out.println(">>> Retornando ao menu principal <<<\n");
    }

    
    
 // Método para realizar a compra de entradas para um espetáculo
    private static void compraEntradas() {
        if (espetaculos.isEmpty()) {
            System.out.println("Nenhum espetáculo cadastrado. Cadastre um espetáculo primeiro.\n");
            return;	// Retorna ao menu se não houver espetáculos cadastrados
        }

        
 // Exibe os espetáculos cadastrados para o usuário escolher
        System.out.println("\n*** VENDA DE ENTRADAS - ESPETÁCULOS ***");
        for (int i = 0; i < espetaculos.size(); i++) {
            Espetaculo espetaculo = espetaculos.get(i);
            System.out.printf("%d) Nome do Espetáculo: %s | Data: %s | Hora: %s | Preço da Entrada Inteira: R$ %.2f\n", 
                              i + 1, espetaculo.getNome(), espetaculo.getData(), espetaculo.getHorario(), espetaculo.getPreco());
        }
        
 // Solicita ao usuário para selecionar um espetáculo
        System.out.print("Selecione um espetáculo (pelo número): ");
        int indexEspectaculo = scanner.nextInt() - 1;	// Subtrai 1 para ajustar o índice
        scanner.nextLine();  

        
 // Verifica se o índice selecionado é válido
        if (indexEspectaculo < 0 || indexEspectaculo >= espetaculos.size()) {
            System.out.println("Espetáculo inválido. Retornando ao menu principal.\n");
            return;
        }

        // Obtém o espetáculo selecionado
        Espetaculo espetaculoSelecionado = espetaculos.get(indexEspectaculo);
        // Inicializa a lista de entradas e o valor total
        List<Entrada> entradas = new ArrayList<>();
        double valorTotal = 0;
        List<Integer> assentosReservadosTemporariamente = new ArrayList<>();  /* Lista de assentos reservados temporariamente (se a compra não 
        for finalizada ele volta a ficar disponível)*/
        
        
        
 // Loop para permitir ao usuário comprar múltiplos ingressos
        while (true) {
        	// Exibe os assentos disponíveis para o espetáculo selecionado
            espetaculoSelecionado.exibirAssentos();

            // Solicita que o usuário escolha um assento
            System.out.print("Escolha o número do assento: ");
            int assentoEscolhido = scanner.nextInt();
            scanner.nextLine();  

            // Verificar se o assento está disponível
            if (!espetaculoSelecionado.getAssentosDisponiveis().contains(assentoEscolhido)) {
                System.out.println("<< Assento indisponível! Tente outro. >> \n");
                continue; // Volta ao início do loop se o assento não estiver disponível
            }

            // Marca o assento como temporariamente reservado
            assentosReservadosTemporariamente.add(assentoEscolhido);
            espetaculoSelecionado.reservarAssento(assentoEscolhido); 
            
            
            // Exibe os tipos de ingresso disponíveis
            System.out.println("||| Tipos de Entrada |||");
            System.out.println("1) Inteira");
            System.out.println("2) Meia         50% do valor da entrada");
            System.out.println("3) Professor    40% do valor da entrada");
            System.out.print("Selecione um tipo de entrada: ");
            int tipoEntrada = scanner.nextInt();
            scanner.nextLine();  
            
            Entrada entrada = espetaculoSelecionado.novaEntrada(tipoEntrada, assentoEscolhido);	// Cria o objeto de entrada com base no tipo selecionado
            double precoFinal = entrada.calculaValor(espetaculoSelecionado.getPreco());	// Calcula o preço final da entrada com o tipo de desconto escolhido
            valorTotal += precoFinal;	// Atualiza o valor total da compra
            entradas.add(entrada);	// Adiciona a entrada à lista de entradas
 // Pergunta ao usuário se deseja comprar outra entrada
            System.out.print("Deseja comprar uma outra entrada (S/N)? ");
            String resposta = scanner.nextLine().trim().toUpperCase();
            if (!resposta.equals("S")) {
                break;	// Se a resposta não for "S", encerra o loop
            }
        }

        // Solicitar CPF para concluir a compra
        System.out.print("Informe o CPF do cliente: ");
        String cpfCliente = scanner.nextLine();

        
        // Busca o cliente pelo CPF
        Cliente cliente = buscarClientePorCPF(cpfCliente);
        if (cliente == null) {
            // Desfaz a reserva se o cliente não for encontrado
            for (Integer assento : assentosReservadosTemporariamente) {
                espetaculoSelecionado.liberarAssento(assento);
            }
            // Zera as entradas não finalizadas e volta ao menu
            entradas.clear();  // Limpa a lista de entradas não finalizadas
            System.out.println("Cliente não encontrado. Todos os assentos temporariamente reservados foram liberados. Retornando ao menu principal.\n");
            return;	// Retorna ao menu principal
        }

        // Finaliza a compra se o cliente foi encontrado
        System.out.printf("\nCliente encontrado: %s - CPF: %s\n", cliente.getNome(), cliente.getCpf());
        System.out.printf("Valor Total: R$ %.2f\n", valorTotal);
        System.out.println(">>> Retorna ao menu principal <<<\n");
    }
 // Método para buscar um cliente pelo CPF
    private static Cliente buscarClientePorCPF(String cpf) {
        for (Cliente cliente : clientes) {
            if (cliente.getCpf().equals(cpf)) {
                return cliente;	// Retorna o cliente se o CPF for encontrado
            }
        }
        return null;	// Retorna null se o cliente não for encontrado
    }
}
