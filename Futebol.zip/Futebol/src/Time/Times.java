package Time;
import java.util.ArrayList;;
public class Times {
	private String nomeTime;
	private int posicaoTabela;
	private String estadio;
	private boolean classificado;
	ArrayList<Jogador> jogadores = new ArrayList <>();
	public Times() {
		
	}
	public Times (String nomeTime, int posicaoTabela, String estadio, boolean classificado) {
		this.nomeTime = nomeTime;
		this.posicaoTabela = posicaoTabela;
		this.estadio = estadio;
		this.classificado = classificado;
	}
	
	
	public String getNomeTime(){
		return nomeTime;
	}
	public void setNomeTime(String nomeTime) {
			this.nomeTime = nomeTime;
	}
	
	public int getPosicaoTabela() {
		return posicaoTabela;
	}
	public void setPosicaoTabela(int posicaoTabela) {
		this.posicaoTabela = posicaoTabela;
	}
	public String getEstadio(){
		return estadio;
		}
	public void setEstadio(String estadio) {
		this.estadio = estadio;
		}
	
	public boolean isClassificado() {
		return classificado;
	}
	public void setClassificado(boolean classificado) {
		this.classificado = classificado;
	}
	public void exibirDados() {
		System.out.println();
		System.out.println("-----------------------------------------");
		System.out.println("\nNome do Time: " + getNomeTime()+ "\nPosição da Tabela: " + getPosicaoTabela() + "\nEstadio: "
		+ getEstadio() + "\nClassificado? " + isClassificado());
		System.out.println("\nLista de jogadores:");
		for(Jogador jogador : jogadores) {
			jogador.exibirDados();
		}
	}
}
