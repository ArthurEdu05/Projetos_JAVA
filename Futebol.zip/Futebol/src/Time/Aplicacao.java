package Time;
import java.util.ArrayList;
public class Aplicacao {
	
	public static void main(String [] args) {
	ArrayList <Times> listaTimes = new ArrayList<>();
	
	Times realMadrid = new Times("Real Madrid", 1, "Santiago Bernabeu", true);
	listaTimes.add(realMadrid);
	
	Jogador cr7 = new Jogador("Cristiano Ronaldo", 32, "Atacante");
	realMadrid.jogadores.add(cr7);
	
	Jogador ramos = new Jogador("Sergio Ramos", 30, "Zagueiro");
	realMadrid.jogadores.add(ramos);
	
	
	Times liverpool = new Times("Liverpool", 2, "Anfield", true);
	listaTimes.add(liverpool);
	
	Jogador salah = new Jogador("Mohamed Salah", 30, "Atacante");
	liverpool.jogadores.add(salah);
	
	Jogador vanDijk = new Jogador("Virgil van Dijk", 28, "Zagueiro");
	liverpool.jogadores.add(vanDijk);
	
	
	Times manUnited = new Times("Manchester United", 3, "Old Trafford", false);
	listaTimes.add(manUnited);
	
	Jogador casemiro = new Jogador("Casemiro", 35, "Meia");
	manUnited.jogadores.add(casemiro);
	Jogador garnacho = new Jogador("Garnacho", 23, "Atacante");
	manUnited.jogadores.add(garnacho);
	
	for(Times times : listaTimes) {
		times.exibirDados();
	}
	
}
	}
