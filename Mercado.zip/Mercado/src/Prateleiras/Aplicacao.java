package Prateleiras;
import java.util.ArrayList;
public class Aplicacao {

	public static void main(String [] args) {
		ArrayList <Produto> listaProdutos = new ArrayList <>();
		
		Produto arroz = new Produto("Arroz", "Grãos", 20, 100);
		listaProdutos.add(arroz);
		
		Produto feijao = new Produto();
		feijao.setNome("Feijao");
		feijao.setSetor("Grãos");
		feijao.setPreco(20);
		feijao.setEstoque(89);
		listaProdutos.add(feijao);
		
		
		Bebida Suco = new Bebida("Suco de uva", "Bebidas", 15, 50, false, "Suco");
		listaProdutos.add(Suco);
		
		ArrayList <Bebida> bebidasMais18 = new ArrayList <>();
		Bebida cerveja = new Bebida("Heineken", "Bebidas Alcoólicas", 7, 245, true, "cerveja");
		bebidasMais18.add(cerveja);
		
		Bebida vinho = new Bebida("Vinho Seco", "Bebidas Alcoólicas", 80, 30, true, "vinho");
		bebidasMais18.add(vinho);
		
		
		int i=1;
		for(Produto produto : listaProdutos) {
			System.out.println("\nProduto " + i);
			produto.exibirDados();
			i++;
		}
		int contador18=1;
		System.out.println("\nAtenção - Esse tipo de Produto não pode ser comercializado para menores de 18 anos!!!");
		for(Bebida bebida : bebidasMais18) {
			System.out.println("\nProduto "+ contador18);
			bebida.exibirDados();
			contador18++;
		}
	}
	
}
