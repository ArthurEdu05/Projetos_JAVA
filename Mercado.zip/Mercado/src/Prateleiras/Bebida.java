package Prateleiras;

public class Bebida extends Produto{
	private boolean alcool;
	private String tipo;
	
	public Bebida() {
		
	}
	public Bebida(String nome, String setor, double preco, int estoque, boolean alcool, String tipo) {
		super(nome, setor, preco, estoque);
		this.alcool = alcool;
		this.tipo = tipo;
	}
	
	public boolean getAlcool() {
		return alcool;
	}
	public void setAlcool(boolean alcool) {
		this.alcool = alcool;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
	@Override
	public void exibirDados() {
		super.exibirDados();
		System.out.println("Alcoólica? " + getAlcool() + "\nTipo: " + getTipo());
	}
}
