package Prateleiras;

public class Produto {
	private String nome;
	private String setor;
	private double preco;
	private int estoque;
	
	public Produto() {
		
	}
	
	public Produto(String nome, String setor, double preco, int estoque) {
		this.nome = nome;
		this.setor = setor;
		this.preco = preco;
		this.estoque = estoque;
	}
	
	
	private String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSetor() {
		return setor;
	}
	public void setSetor(String setor) {
		this.setor = setor;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public int getEstoque() {
		return estoque;
	}
	public void setEstoque(int estoque) {
		this.estoque = estoque;
	}
	
	public void exibirDados() {
		System.out.println("\nNome: " + getNome() + "\nSetor: " + getSetor() + 
		"\nPreço: " + getPreco() + "\nQtd. Disponível: "+ getEstoque());
	}
	
}
