import java.io.BufferedReader;
import java.io.File; // Usado para verificar e acessar arquivos locais
import java.io.FileReader;
import java.io.IOException;
import java.text.Normalizer; // Utilizado para remover acentos de caracteres
import java.util.ArrayList; // Estrutura de dados para armazenar listas dinamicamente
import java.util.List; // Interface de listas
import java.util.Scanner; // Leitura de entradas do usuário no console

public class Main {
    // Declaração da árvore binária de busca que armazenará as palavras
    static BinarySearchTree arvore = new BinarySearchTree(); 
    // Flag para controlar se o discurso foi carregado ou não
    static boolean discursoCarregado = false;

    // Método principal do programa
    public static void main(String[] args) throws IOException {
        try (Scanner sc = new Scanner(System.in)) { // Scanner usado para ler a entrada do usuário
            int opcao = 0; // Armazena a escolha do usuário no menu

            // Loop principal que exibe o menu até o usuário escolher sair
            do {
                // Exibição do menu
                System.out.println("\n--- MENU ---");
                System.out.println("1 - Carregar discurso");
                System.out.println("2 - Contador de palavras");
                System.out.println("3 - Buscar palavra");
                System.out.println("4 - Exibir palavras em ordem alfabética");
                System.out.println("5 - Verificar sinais de depressão");
                System.out.println("6 - Estatísticas");
                System.out.println("7 - Sair");
                System.out.print("Escolha uma opção: ");

                // Lê a entrada do usuário como String
                String entrada = sc.nextLine();
                // Valida se a entrada é um número
                if (entrada.matches("[0-9]+")) {
                    opcao = Integer.parseInt(entrada);
                } else {
                    // Se não for número válido, mostra erro e volta ao menu
                    System.out.println("Entrada inválida! Digite um número entre 1 e 7.");
                    continue; 
                }

                // Executa a ação correspondente à opção escolhida
                switch (opcao) {
                    case 1:
                        carregarDiscurso(); // Chama método para carregar discurso
                        break;
                    case 2:
                        if (discursoCarregado) {
                            // Exibe total de palavras processadas
                            System.out.println("Total de palavras: " + arvore.contarPalavras());
                        } else {
                            System.out.println("Carregue o discurso primeiro.");
                        }
                        break;
                    case 3:
                        if (discursoCarregado) {
                            // Solicita a palavra a ser buscada
                            System.out.print("Digite a palavra a buscar (palavra sem assento): ");
                            String palavraBusca = sc.nextLine().toLowerCase();
                            // Remove acentos e caracteres especiais da palavra digitada
                            palavraBusca = removerAcentos(palavraBusca).replaceAll("[^a-z ]", "").trim();
                            if (!palavraBusca.isEmpty()) {
                                Palavra p = arvore.buscar(palavraBusca); // Busca a palavra na árvore
                                if (p != null) {
                                    // Exibe o número de ocorrências da palavra
                                    System.out.println("\"" + p.getPalavra() + "\" aparece " + p.getOcorrencias() + " vezes.");
                                } else {
                                    System.out.println("Palavra não encontrada no discurso.");
                                }
                            } else {
                                System.out.println("Palavra de busca inválida.");
                            }
                        } else {
                            System.out.println("Carregue o discurso primeiro.");
                        }
                        break;
                    case 4:
                        if (discursoCarregado) {
                            // Exibe todas as palavras ordenadas em ordem alfabética
                            System.out.println("\nPalavras do discurso em ordem alfabética:");
                            arvore.emOrdem(); 
                        } else {
                            System.out.println("Carregue o discurso primeiro.");
                        }
                        break;
                    case 5:
                        if (discursoCarregado) {
                            // Verifica se há palavras associadas à depressão
                            verificarDepressao(); 
                        } else {
                            System.out.println("Carregue o discurso primeiro.");
                        }
                        break;
                    case 6:
                        if (discursoCarregado) {
                            // Exibe estatísticas do discurso
                            estatisticas(); 
                        } else {
                            System.out.println("Carregue o discurso primeiro.");
                        }
                        break;
                    case 7:
                        // Finaliza o programa
                        System.out.println("Integrantes: Arthur Eduardo de Almeida Santos - 10437356, Felipe Ferreira Melantonio RA: 10443843, Manuel Fermín Sánchez Padilla - 10426597"); 
                        System.out.println("Link do vídeo: https://www.youtube.com/watch?v=L8TLUfNtkfk"); 
                        System.out.println("Saindo...");
                        break;
                    default:
                        // Caso o usuário digite um número fora do intervalo
                        System.out.println("Opção inválida.");
                        break;
                }
            } while (opcao != 7); // Continua enquanto o usuário não escolher sair
        }
    }

    // Método utilitário para remover acentos de uma string
    private static String removerAcentos(String str) {
        if (str == null) {
            return null;
        }
        String normalizado = Normalizer.normalize(str, Normalizer.Form.NFD); // Normaliza caracteres acentuados
        return normalizado.replaceAll("\\p{InCombiningDiacriticalMarks}+", ""); // Remove marcas diacríticas
    }

    // Método responsável por carregar e processar o conteúdo do arquivo Discurso.txt
    private static void carregarDiscurso() throws IOException {
        if (discursoCarregado) {
            System.out.println("Discurso já foi carregado. Para carregar um novo, reinicie a aplicação.");
            return;
        }
        // Reinicializa a árvore para garantir estado limpo
        arvore = new BinarySearchTree();

        File arquivoDiscurso = new File("Discurso.txt");
        // Verifica se o arquivo existe e está acessível
        if (!arquivoDiscurso.exists() || !arquivoDiscurso.canRead()) {
            System.out.println("Erro: Arquivo Discurso.txt não encontrado ou não pode ser lido.");
            System.out.println("Por favor, crie o arquivo Discurso.txt no diretório do programa com o texto a ser analisado.");
            return;
        }

        int palavrasLidas = 0; // Contador de palavras válidas inseridas
        try (BufferedReader br = new BufferedReader(new FileReader(arquivoDiscurso))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                // Pré-processamento da linha: caixa baixa, sem acentos e sem caracteres especiais
                linha = linha.toLowerCase();
                linha = removerAcentos(linha);
                linha = linha.replaceAll("[^a-z ]", ""); 
                String[] palavras = linha.split("\\s+"); // Divide por espaços
                for (String p : palavras) {
                    p = p.trim();
                    if (!p.isEmpty()) {
                        arvore.inserir(p); // Insere na árvore
                        palavrasLidas++;
                    }
                }
            }
        }

        // Feedback ao usuário sobre o resultado do carregamento
        if (palavrasLidas > 0) {
            discursoCarregado = true;
            System.out.println("Discurso carregado com sucesso.");
        } else {
            System.out.println("Nenhuma palavra válida encontrada no arquivo Discurso.txt ou o arquivo está vazio.");
            discursoCarregado = false;
        }
    }

    // Verifica presença de palavras associadas à depressão usando o arquivo PalavrasDepressao.txt
    private static void verificarDepressao() throws IOException {
        File arquivoDepressao = new File("PalavrasDepressao.txt");
        if (!arquivoDepressao.exists() || !arquivoDepressao.canRead()) {
            System.out.println("Aviso: Arquivo PalavrasDepressao.txt não encontrado ou não pode ser lido.");
            System.out.println("A verificação de sinais de depressão não pode ser realizada.");
            return;
        }

        List<String> palavrasEncontradasOutput = new ArrayList<>();
        int countPalavrasDepressao = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(arquivoDepressao))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                // Normaliza a palavra para comparação
                String palavraDepProcessada = linha.toLowerCase();
                palavraDepProcessada = removerAcentos(palavraDepProcessada);
                palavraDepProcessada = palavraDepProcessada.replaceAll("[^a-z ]", "").trim();

                if (!palavraDepProcessada.isEmpty()) {
                    Palavra p = arvore.buscar(palavraDepProcessada);
                    if (p != null) {
                        palavrasEncontradasOutput.add("- " + p.getPalavra() + " (" + p.getOcorrencias() + ")");
                        countPalavrasDepressao++;
                    }
                }
            }
        }

        if (countPalavrasDepressao > 0) {
            System.out.println("\nSinais de alerta identificados: " + countPalavrasDepressao + " palavra(s) da lista de depressão encontrada(s) no discurso.");
            System.out.println("Palavras encontradas:");
            for (String output : palavrasEncontradasOutput) {
                System.out.println(output);
            }
        } else {
            System.out.println("\nNenhuma palavra da lista de depressão foi encontrada no discurso.");
        }
    }

    // Lê palavras do arquivo PalavrasDepressao.txt e retorna as encontradas na árvore
    private static List<Palavra> getPalavrasDepressaoEncontradas(BinarySearchTree arvore) throws IOException {
        List<Palavra> palavrasEncontradas = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("PalavrasDepressao.txt"))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String palavraProcessada = linha.toLowerCase();
                palavraProcessada = removerAcentos(palavraProcessada); 
                palavraProcessada = palavraProcessada.replaceAll("[^a-z ]", "").trim();

                if (!palavraProcessada.isEmpty()) {
                    Palavra p = arvore.buscar(palavraProcessada);
                    if (p != null) {
                        palavrasEncontradas.add(p);
                    }
                }
            }
        }
        return palavrasEncontradas;
    }

    // Exibe estatísticas gerais do discurso e sinais de depressão
    private static void estatisticas() throws IOException { 
        System.out.println("\nEstatísticas:");
        // Total de palavras diferentes encontradas na árvore
        System.out.println("- Total de palavras distintas: " + arvore.contarPalavrasDistintas());

        Palavra maisFrequente = arvore.getMaisFrequente();
        if (maisFrequente != null) {
            System.out.println("- Palavra mais frequente: \"" + maisFrequente.getPalavra() + "\" (" + maisFrequente.getOcorrencias() + ")");
        } else {
            System.out.println("- Palavra mais frequente: Nenhuma palavra no discurso.");
        }

        System.out.println("- Palavras que apareceram apenas uma vez: " + arvore.contarPalavrasUnicas());
        System.out.println(); 

        // Estatísticas relacionadas à depressão

        File arquivoDepressao = new File("PalavrasDepressao.txt");
        if (!arquivoDepressao.exists() || !arquivoDepressao.canRead()){
            System.out.println("Aviso: Arquivo PalavrasDepressao.txt não encontrado ou não pode ser lido.");
            System.out.println("As estatísticas de sinais de depressão não podem ser calculadas.");
            return;
        }

        List<Palavra> palavrasDepressaoEncontradas = getPalavrasDepressaoEncontradas(arvore);

        if (palavrasDepressaoEncontradas.isEmpty()) {
    System.out.println("- Nenhuma palavra relacionada à depressão foi encontrada no discurso.");
} else {
    // Ordena manualmente as palavras pela frequência de forma decrescente (sem usar sort)
    for (int i = 0; i < palavrasDepressaoEncontradas.size() - 1; i++) {
        for (int j = 0; j < palavrasDepressaoEncontradas.size() - 1 - i; j++) {
            Palavra p1 = palavrasDepressaoEncontradas.get(j);
            Palavra p2 = palavrasDepressaoEncontradas.get(j + 1);

            if (p1.getOcorrencias() < p2.getOcorrencias()) {
                // Troca os elementos de lugar
                palavrasDepressaoEncontradas.set(j, p2);
                palavrasDepressaoEncontradas.set(j + 1, p1);
            }
        }
    }

    System.out.println("- Palavras relacionadas à depressão encontradas no discurso (" + palavrasDepressaoEncontradas.size() + " distintas):");
    System.out.println("  As 3 mais repetidas são:");
    int limite;
    if (palavrasDepressaoEncontradas.size() < 3) {
    limite = palavrasDepressaoEncontradas.size();
    } else {
    limite = 3;
}
 

    for (int i = 0; i < limite; i++) {
        Palavra p = palavrasDepressaoEncontradas.get(i);
        System.out.println("    - \"" + p.getPalavra() + "\" (" + p.getOcorrencias() + ")");
    }

    if (palavrasDepressaoEncontradas.size() > 3) {
        System.out.println("    (e outras " + (palavrasDepressaoEncontradas.size() - 3) + " palavras de depressão com menos ou igual ocorrências)");
    }
    }
    }
}

