public class BinarySearchTree {
    private Node raiz; // Nó raiz da árvore binária

    // Método público para inserir uma palavra na árvore
    public void inserir(String palavra) {
        raiz = inserirRec(raiz, palavra); // Chamada recursiva passando a raiz
    }

    // Método recursivo que insere uma nova palavra ou incrementa se já existir
    private Node inserirRec(Node atual, String palavra) {
        if (atual == null) {
            return new Node(new Palavra(palavra)); // Cria novo nó se posição estiver vazia
        }

        int cmp = palavra.compareTo(atual.palavra.getPalavra()); // Compara palavras lexicograficamente
        if (cmp < 0) {
            atual.esquerda = inserirRec(atual.esquerda, palavra); // Vai para subárvore esquerda
        } else if (cmp > 0) {
            atual.direita = inserirRec(atual.direita, palavra); // Vai para subárvore direita
        } else {
            atual.palavra.incrementar(); // Palavra já existe, incrementa contador
        }
        return atual; // Retorna o nó atual (com ou sem modificações)
    }

    // Método público para buscar uma palavra na árvore
    public Palavra buscar(String palavra) {
        return buscarRec(raiz, palavra); // Chamada recursiva a partir da raiz
    }

    // Método recursivo que realiza a busca da palavra na árvore
    private Palavra buscarRec(Node atual, String palavra) {
        if (atual == null) return null; // Palavra não encontrada
        int cmp = palavra.compareTo(atual.palavra.getPalavra()); // Compara palavras
        if (cmp == 0) {
            return atual.palavra; // Palavra encontrada
        } else if (cmp < 0) {
            return buscarRec(atual.esquerda, palavra); // Vai para esquerda
        } else {
            return buscarRec(atual.direita, palavra); // Vai para direita
        }
    }

    // Método público para exibir palavras em ordem alfabética
    public void emOrdem() {
        emOrdemRec(raiz); // Chamada recursiva a partir da raiz
    }

    // Percorre a árvore em ordem (esquerda -> raiz -> direita)
    private void emOrdemRec(Node atual) {
        if (atual != null) {
            emOrdemRec(atual.esquerda); // Visita filho esquerdo
            System.out.println(atual.palavra.getPalavra() + " - " + atual.palavra.getOcorrencias()); // Exibe palavra
            emOrdemRec(atual.direita); // Visita filho direito
        }
    }

    // Conta o total de ocorrências de todas as palavras (incluindo repetidas)
    public int contarPalavras() {
        return contarPalavrasRec(raiz); // Chamada recursiva
    }

    // Soma as ocorrências de cada palavra na árvore
    private int contarPalavrasRec(Node atual) {
        if (atual == null) return 0;
        return atual.palavra.getOcorrencias() +
               contarPalavrasRec(atual.esquerda) +
               contarPalavrasRec(atual.direita);
    }

    // Conta o número de palavras distintas (cada nó representa uma)
    public int contarPalavrasDistintas() {
        return contarDistintasRec(raiz); // Chamada recursiva
    }

    // Conta os nós da árvore (1 por palavra distinta)
    private int contarDistintasRec(Node atual) {
        if (atual == null) return 0;
        return 1 + contarDistintasRec(atual.esquerda) + contarDistintasRec(atual.direita);
    }

    // Retorna a palavra com o maior número de ocorrências
    public Palavra getMaisFrequente() {
        return maisFrequenteRec(raiz, null); // Começa a busca com null como atual mais frequente
    }

    // Percorre toda a árvore buscando a palavra com mais ocorrências
    private Palavra maisFrequenteRec(Node atual, Palavra atualMais) {
        if (atual == null) return atualMais; // Caso base da recursão
        if (atualMais == null || atual.palavra.getOcorrencias() > atualMais.getOcorrencias()) {
            atualMais = atual.palavra; // Atualiza se encontrar palavra com mais ocorrências
        }
        atualMais = maisFrequenteRec(atual.esquerda, atualMais); // Verifica subárvore esquerda
        atualMais = maisFrequenteRec(atual.direita, atualMais); // Verifica subárvore direita
        return atualMais;
    }

    // Conta o número de palavras que aparecem exatamente uma vez
    public int contarPalavrasUnicas() {
        return contarUnicasRec(raiz); // Chamada recursiva
    }

    // Soma todos os nós cuja palavra tem exatamente uma ocorrência
    private int contarUnicasRec(Node atual) {
        if (atual == null) return 0;
        int conta = atual.palavra.getOcorrencias() == 1 ? 1 : 0; // Verifica se é única
        return conta + contarUnicasRec(atual.esquerda) + contarUnicasRec(atual.direita);
    }
}
