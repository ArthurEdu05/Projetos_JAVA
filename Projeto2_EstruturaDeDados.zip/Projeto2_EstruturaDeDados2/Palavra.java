public class Palavra {
    private String palavra;
    private int ocorrencias;
// Construtor: inicializa a palavra e define a primeira ocorrência
    public Palavra(String palavra) {
        this.palavra = palavra;
        this.ocorrencias = 1; // Quando a palavra é criada, assume que já apareceu uma vez
    }

    public String getPalavra() {
        return palavra;
    }
// Retorna a quantidade de vezes que a palavra apareceu
    public int getOcorrencias() {
        return ocorrencias;
    }

    public void incrementar() {
        ocorrencias++;
    }
}
