// Arthur Eduardo de Almeida Santos - 10437356
// Kauan Rodrigues Fernandes – 10438316
// Rafael Trindade Dal Maso - 10431850

// Representa um item individual, seja no cardápio ou em um pedido.
public class Item {
    private String descricao;
    private int quantidade;
    private double precoUnitario;

    // Construtor para criar um item com sua descrição, quantidade e preço unitário.
    public Item(String descricao, int quantidade, double  precoUnitario){
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
    }

    public String getDescricao() {
        return descricao;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getPrecoUnitario() {
        return precoUnitario;
    }

    // Calcula o preço total para este item (quantidade * preço unitário).
    public double getPrecoTotal() {
        return quantidade * precoUnitario;
    }
}