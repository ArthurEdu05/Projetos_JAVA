// Arthur Eduardo de Almeida Santos - 10437356
// Kauan Rodrigues Fernandes – 10438316
// Rafael Trindade Dal Maso - 10431850

// Representa um funcionário do tipo Caixa.
class Caixa extends Funcionario {
    // Construtor para criar um Caixa.
    public Caixa(String nome, int id){
        super(nome, id); // Chama o construtor da classe base Funcionario.
    }

    @Override // Sobrescreve o método da classe Funcionario.
    public String getCargo(){
        return "Caixa"; // Retorna o cargo específico.
    }
}