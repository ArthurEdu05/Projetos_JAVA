// Arthur Eduardo de Almeida Santos - 10437356
// Kauan Rodrigues Fernandes – 10438316
// Rafael Trindade Dal Maso - 10431850

// Classe base abstrata para todos os tipos de funcionários.
abstract class Funcionario {

    private String nome;
    private int id;

    // Construtor para inicializar os dados básicos de um funcionário.
    public Funcionario (String nome, int id){
        this.nome = nome;
        this.id = id;
    }

    public String getNome(){
        return nome;
    }

    public int getId(){
        return id;
    }

    // Método abstrato que deve ser implementado pelas subclasses para retornar o cargo específico.
    public abstract String getCargo();
}