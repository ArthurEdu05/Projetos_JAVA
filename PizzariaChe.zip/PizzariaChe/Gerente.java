// Arthur Eduardo de Almeida Santos - 10437356
// Kauan Rodrigues Fernandes – 10438316
// Rafael Trindade Dal Maso - 10431850

// Define o funcionário do tipo Gerente.
class Gerente extends Funcionario {
    private String senha;

    // Construtor para Gerente, inclui a senha.
    public Gerente(String nome, int id, String senha) {
        super(nome, id); // Inicializa atributos da classe Funcionario.
        this.senha = senha;
    }

    @Override
    public String getCargo() {
        return "Gerente";
    }

    // Compara a senha fornecida com a do gerente.
    public boolean validarSenha(String senha) {
        return this.senha.equals(senha);
    }
}