// Arthur Eduardo de Almeida Santos - 10437356
// Kauan Rodrigues Fernandes – 10438316
// Rafael Trindade Dal Maso - 10431850

// Representa um cliente da pizzaria.
class Cliente {
    private String nome;
    private int quantidadePessoas;
    private Mesa mesa;
    private Pedido pedido;

    // Construtor do Cliente: um novo cliente começa sem mesa e com um pedido zerado.
    public Cliente(String nome, int pessoas){
        this.nome = nome;
        this.quantidadePessoas = pessoas;
        this.mesa = null;
        this.pedido = new Pedido();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(){ // Mantido como no original
        this.nome = nome;
    }

    public int getQuantidadePessoas() {
        return quantidadePessoas;
    }

    public void setQuantidadePessoas(int quantidadePessoas) {
        this.quantidadePessoas = quantidadePessoas;
    }

    public Mesa getMesa() {
        return mesa;
    }

    public void setMesa(Mesa mesa) {
        this.mesa = mesa;
    }

    public Pedido getPedido() {
        return pedido;
    }

    // Retorna uma breve descrição do cliente.
    public String toString(){
        return "Cliente representante: " + nome + ", Total de pessoas: " + quantidadePessoas;
    }
}