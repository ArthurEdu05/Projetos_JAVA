// Arthur Eduardo de Almeida Santos - 10437356
// Kauan Rodrigues Fernandes – 10438316
// Rafael Trindade Dal Maso - 10431850

// Representa uma mesa na pizzaria.
public class Mesa {
    private int numero;
    private int capacidade;
    private boolean ocupada;
    private Cliente cliente;

    // Construtor para criar uma nova mesa, definindo seu número e capacidade.
    // A mesa começa desocupada e sem cliente.
    public Mesa(int numero, int capacidade){
        this.numero = numero;
        this.capacidade = capacidade;
        this.ocupada = false;
        this.cliente = null;
    }

    public int getNumero(){
        return numero;
    }

    public int getCapacidade(){
        return capacidade;
    }

    public boolean  isOcupada(){
        return ocupada;
    }

    public Cliente getCliente(){
        return cliente;
    }

    // Atribui um cliente à mesa e a marca como ocupada.
    public void ocuparMesa(Cliente cliente){
        this.cliente = cliente;
        this.ocupada = true;
    }

    // Libera a mesa, removendo o cliente e marcando-a como desocupada.
    public void liberarMesa(){
        this.cliente = null;
        this.ocupada = false;
    }
}