// Arthur Eduardo de Almeida Santos - 10437356
// Kauan Rodrigues Fernandes – 10438316
// Rafael Trindade Dal Maso - 10431850

import java.util.List;
import java.util.ArrayList;

// Representa o pedido de um cliente, com todos os itens selecionados.
public class Pedido {
    // Lista para guardar os itens que compõem este pedido.
    private List<Item> itens;

    // Construtor: cria um novo pedido, que começa vazio.
    public Pedido(){
        this.itens = new ArrayList<>(); // Inicializa a lista de itens.
    }

    // Adiciona um item (produto com sua quantidade e preço) ao pedido.
    public void adicionarItem(Item item){
        this.itens.add(item);
    }

    // Retorna a lista contendo todos os itens deste pedido.
    public List<Item> getItens(){
        return itens;
    }

    // Calcula o valor total do pedido somando o preço total de cada item.
    public double calcularTotal(){
        double total = 0.0;
        // Itera sobre cada item na lista e acumula o seu preço total.
        for (Item item : itens){
            total += item.getPrecoTotal();
        }
        return total; // Retorna o valor final.
    }
}