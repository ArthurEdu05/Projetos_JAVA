// Arthur Eduardo de Almeida Santos - 10437356
// Kauan Rodrigues Fernandes – 10438316
// Rafael Trindade Dal Maso - 10431850

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.Locale;

/**
 * Classe principal que gerencia o sistema da pizzaria.
 * Controla mesas, clientes, pedidos e funcionários.
 */
public class Pizzaria {

    // Listas para armazenar os dados do sistema
    private List<Mesa> mesas;
    private List<Funcionario> funcionarios;
    private List<Cliente> clientes;
    private Gerente gerente;
    private Caixa caixa;
    private double faturamento;
    private Scanner scanner;
    private Cardapio cardapioGlobal;

    /**
     * Construtor que inicializa os componentes principais da pizzaria.
     */
    public Pizzaria() {
        this.scanner = new Scanner(System.in);
        this.cardapioGlobal = new Cardapio();
        inicializarDados(); // Configura dados iniciais do sistema
    }

    /**
     * Inicializa os dados básicos da pizzaria (mesas, funcionários, etc.)
     */
    private void inicializarDados() {
        // Configura mesas com diferentes capacidades
        this.mesas = new ArrayList<>();
        mesas.add(new Mesa(1, 2));
        mesas.add(new Mesa(2, 2));
        mesas.add(new Mesa(3, 4));
        mesas.add(new Mesa(4, 4));
        mesas.add(new Mesa(5, 10));

        // Configura equipe de funcionários
        this.gerente = new Gerente("Helena", 1, "admin123");
        this.funcionarios = new ArrayList<>();
        funcionarios.add(gerente);
        funcionarios.add(new Atendente("João", 2));
        funcionarios.add(new Atendente("Maria", 3));
        funcionarios.add(new Atendente("Carlos", 4));
        funcionarios.add(new Caixa("Ana", 5));

        // Inicializa listas vazias
        this.clientes = new ArrayList<>();
        this.faturamento = 0.0;
    }

    /**
     * Exibe o menu principal e gerencia as opções do sistema.
     */
    public void Menu() {
        int opcao = -1;
        do {
            // Exibe o menu formatado
            System.out.println("\n╔════════════════════════════════════╗");
            System.out.println("║      PIZZARIA CHE BELLA PIZZA      ║");
            System.out.println("╠════════════════════════════════════╣");
            System.out.println("║ Menu Principal:                    ║");
            System.out.println("║ 1. Registrar chegada de cliente    ║");
            System.out.println("║ 2. Alocar cliente em mesa          ║");
            System.out.println("║ 3. Anotar pedido                   ║");
            System.out.println("║ 4. Gerar conta                     ║");
            System.out.println("║ 5. Faturamento do dia              ║");
            System.out.println("║ 6. Listar funcionários             ║");
            System.out.println("║ 7. Encerrar                        ║");
            System.out.println("╚════════════════════════════════════╝");

            System.out.print("Selecione uma opção: ");
            try {
                opcao = scanner.nextInt();
                scanner.nextLine();

                // Gerencia a opção selecionada
                switch (opcao) {
                    case 1:
                        registrarClientes();
                        break;
                    case 2:
                        alocarClienteMesa();
                        break;
                    case 3:
                        anotarPedido();
                        break;
                    case 4:
                        gerarConta();
                        break;
                    case 5:
                        gerarFaturamentoDia();
                        break;
                    case 6:
                        listarFuncionarios();
                        break;
                    case 7:
                        System.out.println("Encerrando o sistema!");
                        break;
                    default:
                        System.out.println("Opção inválida!");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida! Digite apenas números de 1 a 7.");
                scanner.nextLine();
            }
        } while (opcao != 7);
    }

    /**
     * Registra a chegada de um novo grupo de clientes.
     * Valida o nome (apenas letras) e número de pessoas (1-10).
     */
    private void registrarClientes() {
        System.out.println("\n--- Registrar Chegada do Cliente ---");
        
        // Validação do nome (apenas letras e espaços)
        System.out.print("Digite o nome do cliente representante: ");
        String nome = scanner.nextLine();
        while (!nome.matches("[a-zA-Z\\s]+")) {
            System.out.println("Nome inválido! Digite apenas letras e espaços.");
            System.out.print("Digite o nome do cliente representante: ");
            nome = scanner.nextLine();
        }

        // Validação do número de pessoas (1-10)
        System.out.print("Digite a quantidade de pessoas (1-10): ");
        int pessoas = 0;
        try {
            pessoas = scanner.nextInt();
            scanner.nextLine();
            while (pessoas < 1 || pessoas > 10) {
                System.out.println("Quantidade inválida! Digite um número entre 1 e 10.");
                System.out.print("Digite a quantidade de pessoas (1-10): ");
                pessoas = scanner.nextInt();
                scanner.nextLine();
            }
        } catch (InputMismatchException e) {
            System.out.println("Quantidade de pessoas inválida. Por favor, insira um número.");
            scanner.nextLine();
            return;
        }

        // Cria e armazena o novo cliente
        Cliente cliente = new Cliente(nome, pessoas);
        clientes.add(cliente);
        System.out.println(nome + " está aguardando. Aloque-o(s) em uma mesa.");
    }

    /**
     * Aloca um cliente registrado a uma mesa disponível.
     * Mostra status das mesas e aplica regras de alocação.
     */
    private void alocarClienteMesa() {
        System.out.println("\n--- Alocar Cliente em Mesa ---");
        
        // Verifica se há clientes para alocar
        if (clientes.isEmpty()) {
            System.out.println("Nenhum cliente registrado para alocação no momento.");
            return;
        }

        // Exibe tabela com status das mesas
        System.out.println("\nStatus das Mesas:");
        System.out.println("-----------------------------------------");
        System.out.println("| Nº | Capacidade | Status      | Cliente          | Pessoas |");
        System.out.println("-----------------------------------------");
        for (Mesa mesa : mesas) {
            String status = mesa.isOcupada() ? "Ocupada" : "Disponível";
            String clienteNome = mesa.isOcupada() ? mesa.getCliente().getNome() : "-";
            String pessoas = mesa.isOcupada() ? String.valueOf(mesa.getCliente().getQuantidadePessoas()) : "-";
            
            System.out.printf("| %-2d | %-10d | %-11s | %-15s | %-7s |\n",
                             mesa.getNumero(), mesa.getCapacidade(), status, clienteNome, pessoas);
        }
        System.out.println("-----------------------------------------");

        // Processa alocação do cliente
        System.out.print("Digite o nome do cliente representante para alocar à mesa: ");
        String nomeCliente = scanner.nextLine();

        // Busca cliente não alocado
        Cliente clienteParaAlocar = null;
        for (Cliente c : clientes) {
            if (c.getNome() != null && c.getNome().equalsIgnoreCase(nomeCliente) && c.getMesa() == null) {
                clienteParaAlocar = c;
                break;
            }
        }

        // Verifica se cliente já está alocado
        if (clienteParaAlocar == null) {
            for (Cliente c : clientes) {
                if (c.getNome() != null && c.getNome().equalsIgnoreCase(nomeCliente) && c.getMesa() != null) {
                    System.out.println("Cliente " + nomeCliente + " já está alocado na mesa " + c.getMesa().getNumero() + ".");
                    return;
                }
            }
            System.out.println("Cliente representante '" + nomeCliente + " não encontrado ou não aguardando alocação.");
            return;
        }

        // Encontra a melhor mesa disponível
        Mesa melhorMesa = null;
        int menorCapacidadeAdequada = Integer.MAX_VALUE;
        int numPessoasCliente = clienteParaAlocar.getQuantidadePessoas();

        for (Mesa mesa : mesas) {
            if (!mesa.isOcupada()) {
                boolean capacidadeSuficiente = numPessoasCliente <= mesa.getCapacidade();
                boolean ocupacaoMinima = numPessoasCliente >= (mesa.getCapacidade() * 0.5);

                if (capacidadeSuficiente && ocupacaoMinima) {
                    if (mesa.getCapacidade() < menorCapacidadeAdequada) {
                        menorCapacidadeAdequada = mesa.getCapacidade();
                        melhorMesa = mesa;
                    }
                }
            }
        }

        // Aloca cliente ou informa indisponibilidade
        if (melhorMesa != null) {
            melhorMesa.ocuparMesa(clienteParaAlocar);
            clienteParaAlocar.setMesa(melhorMesa);
            System.out.println("Cliente " + clienteParaAlocar.getNome() + " (grupo de " + numPessoasCliente +
                    " pessoas) foi alocado para a mesa " + melhorMesa.getNumero() +
                    " (capacidade para " + melhorMesa.getCapacidade() + " pessoas).");
        } else {
            System.out.println("Desculpe, " + clienteParaAlocar.getNome() +
                    ". Não temos mesa disponível no momento, a pizzaria está lotada ou não há mesa adequada para " +
                    numPessoasCliente + " pessoa(s) no momento.");
        }
    }

    /**
     * Registra os itens do pedido de uma mesa.
     * Mostra mesas ocupadas e cardápio antes de anotar.
     */
    private void anotarPedido() {
        System.out.println("\n--- Anotar Pedido ---");
        
        // Verifica se há mesas ocupadas
        boolean hasOccupiedTables = false;
        for (Mesa m : mesas) {
            if (m.isOcupada()) {
                hasOccupiedTables = true;
                break;
            }
        }
        
        if (!hasOccupiedTables) {
            System.out.println("Nenhuma mesa está alocada no momento. Não é possível anotar pedidos.");
            return;
        }

        // Mostra mesas ocupadas disponíveis para pedido
        System.out.println("\nMesas Ocupadas:");
        System.out.println("-----------------------------------------");
        System.out.println("| Nº | Cliente          | Pessoas |");
        System.out.println("-----------------------------------------");
        for (Mesa mesa : mesas) {
            if (mesa.isOcupada() && mesa.getCliente() != null) {
                System.out.printf("| %-2d | %-15s | %-7d |\n",
                                mesa.getNumero(), 
                                mesa.getCliente().getNome(),
                                mesa.getCliente().getQuantidadePessoas());
            }
        }
        System.out.println("-----------------------------------------");

        // Seleciona mesa para pedido
        System.out.print("Digite o número da mesa para anotar o pedido: ");
        int numeroMesaDigitado;
        try {
            numeroMesaDigitado = scanner.nextInt();
            scanner.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Número da mesa inválido. Por favor, digite um número.");
            scanner.nextLine();
            return;
        }

        // Valida mesa selecionada
        Mesa mesaDoPedido = null;
        for (Mesa m : mesas) {
            if (m.getNumero() == numeroMesaDigitado) {
                mesaDoPedido = m;
                break;
            }
        }

        if (mesaDoPedido == null) {
            System.out.println("Mesa " + numeroMesaDigitado + " não encontrada.");
            return;
        }

        if (!mesaDoPedido.isOcupada() || mesaDoPedido.getCliente() == null) {
            System.out.println("Mesa " + numeroMesaDigitado + " não está ocupada por um cliente.");
            return;
        }

        Cliente clienteDaMesa = mesaDoPedido.getCliente();

        // Verifica se pedido já foi feito
        if (clienteDaMesa.getPedido() != null && !clienteDaMesa.getPedido().getItens().isEmpty()) {
            System.out.println("O cliente da mesa " + numeroMesaDigitado + " (" + clienteDaMesa.getNome() + ") já realizou seu pedido.");
            System.out.println("Não é possível adicionar mais itens através desta opção.");
            return;
        }

        // Mostra cardápio
        System.out.println("\n--- Cardápio Che Bella Pizza ---");
        cardapioGlobal.exibirCardapio();
        System.out.println("----------------------------------");

        // Processa itens do pedido
        Pedido pedidoAtual = clienteDaMesa.getPedido();
        String nomeItemDesejado;
        
        while (true) {
            System.out.print("Digite o nome do item desejado (ou 'fim' para concluir o pedido): ");
            nomeItemDesejado = scanner.nextLine();

            if (nomeItemDesejado.equalsIgnoreCase("fim")) {
                break;
            }

            // Busca item no cardápio
            Item itemDoCardapio = cardapioGlobal.buscarItem(nomeItemDesejado);

            if (itemDoCardapio == null) {
                System.out.println("Item '" + nomeItemDesejado + "' não encontrado no cardápio. Verifique o nome e tente novamente.");
                continue;
            }

            // Valida quantidade
            int quantidade = 0;
            boolean quantidadeValida = false;
            while(!quantidadeValida) {
                System.out.print("Digite a quantidade para '" + itemDoCardapio.getDescricao() + "': ");
                try {
                    quantidade = scanner.nextInt();
                    scanner.nextLine();
                    if (quantidade > 0) {
                        quantidadeValida = true;
                    } else {
                        System.out.println("A quantidade deve ser maior que zero.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Quantidade inválida. Por favor, digite um número.");
                    scanner.nextLine();
                }
            }

            // Adiciona item ao pedido
            Item itemParaPedido = new Item(itemDoCardapio.getDescricao(), quantidade, itemDoCardapio.getPrecoUnitario());
            pedidoAtual.adicionarItem(itemParaPedido);
            System.out.println("'" + quantidade + "x " + itemDoCardapio.getDescricao() + "' adicionado(s) ao pedido da mesa " + numeroMesaDigitado + ".");
        }

        // Confirmação do pedido
        if (pedidoAtual.getItens().isEmpty()) {
            System.out.println("Nenhum item foi adicionado ao pedido da mesa " + numeroMesaDigitado + ".");
        } else {
            System.out.println("Pedido para o cliente " + clienteDaMesa.getNome() + " da mesa " + numeroMesaDigitado + " registrado com sucesso!");
        }
    }

    /**
     * Gera a conta de uma mesa e a libera.
     * Mostra mesas ocupadas antes de selecionar.
     */
    private void gerarConta() {
        System.out.println("\n--- Gerar Conta ---");
        
        // Verifica se há mesas ocupadas
        boolean hasOccupiedTables = false;
        for (Mesa m : mesas) {
            if (m.isOcupada()) {
                hasOccupiedTables = true;
                break;
            }
        }
        
        if (!hasOccupiedTables) {
            System.out.println("Nenhuma mesa está alocada no momento. Não é possível gerar contas.");
            return;
        }

        // Mostra mesas ocupadas disponíveis
        System.out.println("\nMesas Ocupadas:");
        System.out.println("-----------------------------------------");
        System.out.println("| Nº | Cliente          | Pessoas |");
        System.out.println("-----------------------------------------");
        for (Mesa mesa : mesas) {
            if (mesa.isOcupada() && mesa.getCliente() != null) {
                System.out.printf("| %-2d | %-15s | %-7d |\n",
                                mesa.getNumero(), 
                                mesa.getCliente().getNome(),
                                mesa.getCliente().getQuantidadePessoas());
            }
        }
        System.out.println("-----------------------------------------");

        // Seleciona mesa para gerar conta
        System.out.print("Digite o número da mesa para gerar a conta: ");
        int numeroMesaDigitado;
        try {
            numeroMesaDigitado = scanner.nextInt();
            scanner.nextLine();
        } catch (InputMismatchException e) {
            System.out.println("Número da mesa inválido. Por favor, digite um número.");
            scanner.nextLine();
            return;
        }

        // Valida mesa selecionada
        Mesa mesaParaConta = null;
        for (Mesa m : mesas) {
            if (m.getNumero() == numeroMesaDigitado) {
                mesaParaConta = m;
                break;
            }
        }

        if (mesaParaConta == null) {
            System.out.println("Mesa " + numeroMesaDigitado + " não encontrada.");
            return;
        }

        if (!mesaParaConta.isOcupada() || mesaParaConta.getCliente() == null) {
            System.out.println("Mesa " + numeroMesaDigitado + " não está ocupada ou não tem um cliente associado.");
            return;
        }

        Cliente clienteDaConta = mesaParaConta.getCliente();
        Pedido pedidoDoCliente = clienteDaConta.getPedido();

        // Verifica se há itens no pedido
        if (pedidoDoCliente == null || pedidoDoCliente.getItens().isEmpty()) {
            System.out.println("O cliente " + clienteDaConta.getNome() + " na mesa " + numeroMesaDigitado + " não possui itens no pedido.");
            System.out.println("Não é possível gerar a conta.");
            return;
        }

        // Gera conta formatada
        System.out.println("\n===== Pizzaria Che Bella Pizza =====");
        System.out.println("=========      CONTA       =========");
        System.out.println("Mesa: " + mesaParaConta.getNumero());
        System.out.println("Cliente: " + clienteDaConta.getNome());
        System.out.println("Pessoas na Mesa: " + clienteDaConta.getQuantidadePessoas());
        System.out.println("-------------------------------------");
        System.out.println("Itens Consumidos:");

        // Lista itens do pedido
        for (Item item : pedidoDoCliente.getItens()) {
            System.out.printf(Locale.US, " - %dx %s (R$ %.2f cada) - Total: R$ %.2f\n",
                    item.getQuantidade(), item.getDescricao(), item.getPrecoUnitario(), item.getPrecoTotal());
        }

        // Calcula totais
        System.out.println("-------------------------------------");
        double valorTotalPedido = pedidoDoCliente.calcularTotal();
        System.out.printf(Locale.US, "Valor Total do Pedido: R$ %.2f\n", valorTotalPedido);

        if (clienteDaConta.getQuantidadePessoas() > 0) {
            double valorPorPessoa = valorTotalPedido / clienteDaConta.getQuantidadePessoas();
            System.out.printf(Locale.US, "Valor por Pessoa: R$ %.2f\n", valorPorPessoa);
        }
        System.out.println("=====================================");
        System.out.println("Obrigado e volte sempre!");

        // Atualiza faturamento e libera mesa
        this.faturamento += valorTotalPedido;
        mesaParaConta.liberarMesa();
        clienteDaConta.setMesa(null);

        System.out.println("\nConta da mesa " + numeroMesaDigitado + " gerada com sucesso.");
        System.out.println("Mesa " + numeroMesaDigitado + " liberada.");
    }

    /**
     * Exibe o faturamento acumulado do dia.
     * Requer autenticação do gerente.
     */
    private void gerarFaturamentoDia() {
        System.out.println("\n--- Faturamento Acumulado do Dia ---");
        int tentativas = 0;
        int maxTentativas = 3;

        // Autenticação do gerente
        while (tentativas < maxTentativas) {
            System.out.print("Digite a senha do gerente: ");
            String senhaDigitada = scanner.nextLine();

            if (gerente.validarSenha(senhaDigitada)) {
                System.out.printf(Locale.US, "Faturamento Acumulado do Dia: R$ %.2f\n", this.faturamento);
                return;
            } else {
                tentativas++;
                int restantes = maxTentativas - tentativas;
                if (restantes > 0) {
                    System.out.println("Senha incorreta! Tente novamente. Faltam " + restantes + " tentativa(s).");
                } else {
                    System.out.println("Você excedeu o limite de tentativas. Acesso negado.");
                }
            }
        }
        System.out.println("Voltando ao menu principal.");
    }

    /**
     * Lista todos os funcionários do sistema.
     * Requer autenticação do gerente.
     */
    private void listarFuncionarios() {
        System.out.println("\n--- Listar Funcionários ---");
        int tentativas = 0;
        int maxTentativas = 3;

        // Autenticação do gerente
        while (tentativas < maxTentativas) {
            System.out.print("Digite a senha do gerente: ");
            String senha = scanner.nextLine();

            if (gerente.validarSenha(senha)) {
                System.out.println("\nLista de Funcionários:");
                for (Funcionario funcionario : funcionarios) {
                    System.out.println("Nome: " + funcionario.getNome() + " | ID: " + funcionario.getId()
                            + " | Cargo: " + funcionario.getClass().getSimpleName());
                }
                return;
            } else {
                tentativas++;
                int restantes = maxTentativas - tentativas;
                if (restantes > 0) {
                    System.out.println("Senha incorreta! Tente novamente. Faltam " + restantes + " tentativa(s).");
                } else {
                    System.out.println("Você excedeu o limite de tentativas. Voltando ao menu.");
                }
            }
        }
    }
    
    //Ponto de entrada do programa
    public static void main(String[] args) {
        new Pizzaria().Menu();
    }
}