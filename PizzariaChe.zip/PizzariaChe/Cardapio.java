// Arthur Eduardo de Almeida Santos - 10437356
// Kauan Rodrigues Fernandes – 10438316
// Rafael Trindade Dal Maso - 10431850

import java.util.ArrayList;
import java.util.List;

// Define e gerencia os itens do cardápio da pizzaria.
public class Cardapio {
    private List<Item> itens;

    // Construtor: Popula o cardápio com os itens iniciais.
    public Cardapio() {
        this.itens = new ArrayList<>();
        this.itens.add(new Item("Pizza 4 queijos", 1, 100.0));
        this.itens.add(new Item("Pizza muçarela", 1, 60.0));
        this.itens.add(new Item("Pizza portuguesa", 1, 80.0));
        this.itens.add(new Item("Água com gás", 1, 15.0));
        this.itens.add(new Item("Água sem gás", 1, 15.0));
        this.itens.add(new Item("Suco de limão", 1, 20.0));
        this.itens.add(new Item("Suco de laranja", 1, 25.0));
    }

    // Mostra os itens do cardápio no console.
    public void exibirCardapio() {
        for(Item item: itens){
            System.out.println(item.getDescricao() + " - R$" + item.getPrecoUnitario());
        }
    }

    // Procura um item no cardápio pelo nome.
    // Retorna uma *nova cópia* do item se achado, para não alterar o cardápio original.
    public Item buscarItem(String descricao) {
        for (Item item : itens){
            if(item.getDescricao().equalsIgnoreCase(descricao)){
                // Cria uma nova instância para ser usada no pedido.
                return new Item(item.getDescricao(), 1, item.getPrecoUnitario());
            }
        }
        return null; // Não encontrou o item.
    }
}