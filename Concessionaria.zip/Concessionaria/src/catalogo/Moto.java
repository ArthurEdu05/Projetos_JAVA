package catalogo;

public class Moto extends Veiculo{
	private String tipo;
	private boolean manobra;
	
	
	public Moto() {
		
	}
	
	public Moto(String nome, String cor, int roda, double preco, boolean eletrico,String tipo, boolean manobra) {
		super(nome, cor, roda, preco, eletrico);
		this.tipo= tipo;
		this.manobra = manobra;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public boolean getManobra() {
		return manobra;
	}
	public void setManobra(boolean manobra) {
		this.manobra = manobra;
	}
	@Override
	public void exibirDados() {
		System.out.println("\nNome: "+ getNome() + "\nCor: " 
		+ getCor() + "\nQtd. Rodas: " + getRoda() + "\nPreço: " + getPreco() 
		+ "\nElétrico? " + getEletrico() + "\nTipo: " + getTipo() + "\nFaz manobras? " + getManobra());
	}
}
