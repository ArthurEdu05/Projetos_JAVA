package catalogo;

public class Veiculo {
	private String nome;
	private String cor;
	private int roda;
	private double preco;
	private boolean eletrico;
	
	
	public Veiculo() {
		
	}
	
	public Veiculo (String nome, String cor, int roda, double preco, boolean eletrico) {
		this.nome = nome;
		this.cor = cor;
		this.roda = roda;
		this.preco = preco;
		this.eletrico = eletrico;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String n) {
		this.nome = n;
	}
	
	public String getCor() {
		return cor;
	}
	public void setCor(String c) {
		this.cor = c;
	}
	
	public int getRoda() {
		return roda;
	}
	public void setRoda(int r) {
		this.roda = r;
	}
	
	public double getPreco() {
		return preco;
	}
	public void setPreco(double p) {
		this.preco = p;
	}
	
	public boolean getEletrico() {
		return eletrico;
	}
	
	public void setEletrico(boolean e) {
		this.eletrico = e;
	}
	
	
	public void exibirDados() {
		System.out.println("\nNome: "+ getNome() + "\nCor: " 
	+ getCor() + "\nQtd. Rodas: " + getRoda() + "\nPreço: " + getPreco() 
	+ "\nElétrico? " + getEletrico());
	}
	
}
