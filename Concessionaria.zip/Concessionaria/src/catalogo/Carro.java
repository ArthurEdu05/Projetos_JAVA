package catalogo;

public class Carro extends Veiculo {
	private String tipo;
	private int ano;
	private boolean tetoSolar;
	
	public Carro() {
		
	}
	public Carro(String nome, String cor, int roda, double preco, boolean eletrico, String tipo, int ano, boolean teto) {
		super(nome, cor, roda, preco, eletrico);
		this.tipo = tipo;
		this.ano = ano;
		this.tetoSolar = teto;
	}
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String t) {
		this.tipo = t;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public boolean getTetoSolar() {
		return tetoSolar;
	}
	public void setTetoSolar(boolean teto) {
		this.tetoSolar = teto;
	}
	@Override
	public void exibirDados() {
		System.out.println("\nNome: "+ getNome() + "\nCor: " + getCor()
		+ "\nQtd. Rodas: " + getRoda() + "\nPreço: " + getPreco() 
		+ "\nElétrico? " + getEletrico() + "\nTipo: " + getTipo() + 
		"\nAno: " + getAno() + "\nTeto Solar? " + getTetoSolar() + "\n");
	}
	
}
