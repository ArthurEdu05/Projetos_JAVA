package catalogo;

public class Aplicacao {

	public static void main(String[] args) {
		Veiculo quadriciclo = new Veiculo("Honda quadriciclo", "Vermelho", 4, 21.796, true);
		quadriciclo.exibirDados();
		
		Carro porsche = new Carro("Porsche GT3 RS", "Preto", 4, 2320000, false, "Esportivo", 2024, false);
		porsche.exibirDados();
		
		Moto cg150 = new Moto("CG 150", "Prata", 2, 10000,false, "Comum", true);
		cg150.exibirDados();
	}

}
