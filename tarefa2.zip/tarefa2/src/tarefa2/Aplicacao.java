package tarefa2;
import java.util.Scanner;

public class Aplicacao {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Empresa empresa = new Empresa("TechMack", "Rua da consolação, 123");

        while (true) {
            System.out.println("Menu:");
            System.out.println("1 - Cadastrar funcionário");
            System.out.println("2 - Procurar funcionário pelo Id");
            System.out.println("3 - Exibir lista de funcionários");
            System.out.println("4 - Excluir funcionário");
            System.out.println("5 - Sair");
            System.out.print("Escolha uma opção: ");
            int op = entrada.nextInt();

            switch (op) {
                case 1:
                    System.out.println("Nome completo: ");
                    String nome = entrada.next();
                    System.out.println("Dia da contratação: ");
                    int dia = entrada.nextInt();
                    System.out.println("Mês da contratação: ");
                    int mes = entrada.nextInt();
                    System.out.println("Ano da contratação: ");
                    int ano = entrada.nextInt();
                    System.out.println("Salário: ");
                    double salario = entrada.nextDouble();
                    System.out.println("Cargo: ");
                    String cargo = entrada.next();
                    System.out.println("ID: ");
                    int id = entrada.nextInt();

                    Data data = new Data(dia, mes, ano);
                    Funcionario funcionario = new Funcionario(nome, data, salario, cargo, id);
                    empresa.addFuncionario(funcionario);
                    System.out.println("Funcionário cadastrado com sucesso!");
                    break;

                case 2:
                    System.out.print("Digite o ID do funcionário: ");
                    int idBuscar = entrada.nextInt();
                    Funcionario funcionarioEncontrado = empresa.buscarFuncPorId(idBuscar);
                    if (funcionarioEncontrado != null) {
                    	 System.out.println("Funcionário encontrado - Nome: " + funcionarioEncontrado.getNomeCompleto());
                    } else {
                        System.out.println("Funcionário não encontrado.");
                    }
                    break;

                case 3:
                    System.out.println("Lista de Funcionários:");
                    for (Funcionario f : empresa.getFuncionarios()) {
                        System.out.println("ID: " + f.getId() + ", Nome: " + f.getNomeCompleto() + ", Salario:" + f.getSalario() + ", Cargo: " + f.getCargo() + ", Data de Contratação: " + f.getDataContratacao());
                    }
                    break;

                case 4:
                    System.out.print("Digite o ID do funcionário para excluir: ");
                    int idExcluir = entrada.nextInt();
                    if (empresa.removerFuncionario(idExcluir)) {
                        System.out.println("Funcionário excluído com sucesso!");
                    } else {
                        System.out.println("Funcionário não encontrado.");
                    }
                    break;

                case 5:
                    System.out.println("Saindo...");
                    System.out.println("Você Saiu!");
                    entrada.close();
                    return;

                default:
                    System.out.println("Opção inválida.");
            }
        }
    }
}

