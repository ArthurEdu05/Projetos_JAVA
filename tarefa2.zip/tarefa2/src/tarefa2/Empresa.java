package tarefa2;

import java.util.ArrayList;
import java.util.List;

public class Empresa {
    private String nome;
    private String endereco;
    private List<Funcionario> funcionarios;

    public Empresa(String nome, String endereco) {
        this.nome = nome;
        this.endereco = endereco;
        this.funcionarios = new ArrayList<Funcionario>();
    }

    public void addFuncionario(Funcionario funcionario) {
        funcionarios.add(funcionario);
    }

    public Funcionario buscarFuncPorId(int id) {
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getId() == id) {
                return funcionario;
            }
        }
        return null;
    }

    public List<Funcionario> getFuncionarios() {
        return funcionarios;
    }

    public boolean removerFuncionario(int id) {
        return funcionarios.removeIf(funcionario -> funcionario.getId() == id);
    }

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }
}
