package tarefa2;

public class Funcionario {
    private String nomeCompleto;
    private Data dataContratacao;
    private double salario;
    private String cargo;
    private int id;

    public Funcionario(String nomeCompleto, Data dataContratacao, double salario, String cargo, int id) {
        this.nomeCompleto = nomeCompleto;
        this.dataContratacao = dataContratacao;
        this.salario = salario;
        this.cargo = cargo;
        this.id = id;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public Data getDataContratacao() {
        return dataContratacao;
    }

    public double getSalario() {
        return salario;
    }

    public String getCargo() {
        return cargo;
    }

    public int getId() {
        return id;
    }
}

